#pragma once
#include <deque>
#include <vector>
#include "stdafx.h"
using namespace Suzu;
using std::deque;
using std::vector;

#ifdef __cplusplus
extern "C" {
#endif

#define EXPORTFUNC __declspec(dllexport)

  EXPORTFUNC Message *TestEntry(deque<string> &res);
  EXPORTFUNC vector<string> *Attachment(void);
#ifdef __cplusplus
}
#endif